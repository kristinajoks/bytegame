class User:

    def __init__(self, color):
        self.color = color
        self.score = 0
    
    